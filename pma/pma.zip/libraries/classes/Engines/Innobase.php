<?php
/**
 * The Innobase storage engine
 */

declare(strict_types=1);

namespace PhpMyAdmin\Engines;

/**
 * The Innobase storage engine
 */
class Innobase extends Innodb
{
}
